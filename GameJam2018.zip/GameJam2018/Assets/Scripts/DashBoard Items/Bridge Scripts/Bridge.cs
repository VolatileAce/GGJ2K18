﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bridge : MonoBehaviour {

	public virtual void doButtonClick(bool input)
    {

    }

    public virtual void doSliderChange(float input)
    {

    }
}
