﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public enum TorsoLimbType
{
    Null,

    Red,
    Blue,
    Green,

    MAX_TYPES
}

public enum LimbSide
{
    Center,
    Left,
    Right
}

public class AlienTorsoLimb : AlienLimb
{
    public TorsoLimbType Limb;
    public LimbSide Side;

    public override LimbLocation Location
    {
        get
        {
            return LimbLocation.Torso;
        }
    }

    public AlienTorsoLimb(TorsoLimbType in_Limb)
    {
        Limb = in_Limb;
    }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
